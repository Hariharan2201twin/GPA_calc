<!DOCTYPE html>
<html>
<head>
	<title>c</title>
</head>
<body>
<form action="c1.php" method="post">
Name:<input type="text" name="name"><br>
Semester:<input type="text" name="a"><br>
Year:<input type="text" name="b"><br>
Dept:<input type="text" name="c"><br>
<input type="submit" value="login">
</form>
</body>
</html>